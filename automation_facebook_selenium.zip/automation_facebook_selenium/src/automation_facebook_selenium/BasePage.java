package automation_facebook_selenium;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;

/* 
Class Purpose:
	- Foundation for framework functionality (clicking, screenshots, etc)
	- Using inheritance, this class will be extended to other classes for test cases
	- Actions below include website navigation and browser interaction 
	
Misc. Notes:
	- Some of the methods below for website navigation incorporate a screenshot feature for failing scenarios
*/

public class BasePage extends WebDriverFactory {

	private String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
	public Actions actions = new Actions(WebDriverFactory.getDriver());

	// Note: Will take screenshot and output as a JPG file
	private static void takeScreenshot(String fileName) {

		// Note: SimpleDateFormat can be changed to other formats, for example "MM/dd/yyy" only
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Date date = new Date();
		String time = sdf.format(date);

		// Note: Screenshots will be labeled as "Screenshot name MM/dd/yyyy HH:mm:ss"
		try {
			File src = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(src, new File(fileName + time + ".jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Note: Methods below used to interact with page elements, includes:
	// - click, send text, get text, clear text, compare text, page scroll, and mouse hover
	public void click(By locator) {

		try {
			getDriver().findElement(locator).click();
		} catch (NoSuchElementException error) {
			takeScreenshot(timestamp);
			error.printStackTrace();
			throw new NoSuchElementException(locator + " element not found!");
		}
	}

	public void sendText(By locator, String text) {

		try {
			getDriver().findElement(locator).sendKeys(text);
		} catch (NoSuchElementException error) {
			takeScreenshot(timestamp);
			error.printStackTrace();
			throw new NoSuchElementException(locator + " element not found!");
		}
	}

	public String getTextFromElement(By locator) {

		String text = null;
		try {
			text = getDriver().findElement(locator).getText();
		} catch (NoSuchElementException error) {
			Assert.fail("Element is not found with this locator: " + locator.toString());
			error.printStackTrace();
		}
		return text;
	}

	public String getTextToCompare(By locator, String anyText) {

		String actualText = getDriver().findElement(locator).getText();
		assertEquals(actualText, anyText);
		if (actualText.equals(anyText)) {
			System.out.println("Text Matches");
		} else {
			System.out.println("Text DOES NOT MATCH");
		}
		return actualText;
	}

	public void scrollDown() throws InterruptedException {
		
		// Note: Vertical scroll by pixel amount
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("window.scrollBy(0, document.body.scrollHeight)");
		// Thread.sleep(3000);
	}

	public void clearText(By locator) {
		
		getDriver().findElement(locator).clear();
	}

	public static void hoverOver(By locator) throws InterruptedException {
		
		WebElement element = getDriver().findElement(locator);
		Actions hoveringAction = new Actions(getDriver());
		// Note: Will move to the specified element and hover using build/perform
		hoveringAction.moveToElement(element).build().perform();
		hoveringAction.wait(2000);
		// Thread.sleep(2000);
	}

	// Note: Method will wait for a condition and specifies how frequently it was check for element before timeout
	public static WebElement webDriverFluentWait(final By locator) {
		
		Wait<WebDriver> wait = new FluentWait<WebDriver>(getDriver())
			// Note: Maximum wait time is 15 seconds
			.withTimeout(15, TimeUnit.SECONDS)
			// Note: Will check for element every second to see if its there 
			.pollingEvery(1, TimeUnit.SECONDS)
			// Note: Will ignore these 3 exceptions while test is running
			.ignoring(NoSuchElementException.class)
			.ignoring(StaleElementReferenceException.class)
			.ignoring(ElementNotFoundException.class)
			// Note: If we don't find the element, this will display
			.withMessage("WebDriver waited 15 seconds but couldn't find element");
					
		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver driver) {
				return driver.findElement(locator);
						
			}
		});
		return element;
}

	// Note: Methods below will control actions for web browsers, includes:
	// - back arrow, forward arrow, refresh, switching window, close windows
	public void clickBrowserBackArrow() {
		
		getDriver().navigate().back();
	}

	public void clickBrowserForwardArrow() {
		
		getDriver().navigate().forward();
	}

	public void refreshBrowser() {
		
		getDriver().navigate().refresh();
	}

	// Note: Switching to window based on index
	public static void switchToWindow(int index) {
		
		List<String> listOfWindows = new ArrayList<String>(getDriver().getWindowHandles());
		// Note: Uses driver to switch between windows based on the index, beginning at 0
		getDriver().switchTo().window(listOfWindows.get(index));
	}

	// Note: Closes current window and switches back to root window (0)
	public static void switchToRootWindowAndCloseOtherBrowsers() {
		
		List<String> listOfWindows = new ArrayList<String>(getDriver().getWindowHandles());
		for (int i = 1; i < listOfWindows.size(); i++) {
			getDriver().switchTo().window(listOfWindows.get(i));
			getDriver().close();
		}
		getDriver().switchTo().window(listOfWindows.get(0));
	}

}
