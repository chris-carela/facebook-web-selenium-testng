package automation_facebook_selenium;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

/* 
Class Purpose:
	- WebDriver for test execution, controls before and after annotations for tests
	- Manage launch of Chrome or Firefox browsers here by uncommenting appropriate code
	
Misc. Notes:
	- Must have Google Chrome and Mozilla Firefox JAR files installed locally to run test
	- Chrome JAR can be found here https://sites.google.com/a/chromium.org/chromedriver/downloads 
	- Firefox JAR can be found here https://www.seleniumhq.org/download/ 
*/

public class WebDriverFactory {
		
// Note: WebDriver and URL objects, specify desired website for testing	
	private static WebDriver driver = null;
	private static final String URL = "https://facebook.com";	

// Note: @BeforeClass behavior below will execute before each test case
	@BeforeClass
	public void intializeWebDriver() throws MalformedURLException, InterruptedException{

// Note: Currently, test will be executed in Chrome, to run in Firefox, uncomment code 
		// Chrome Driver		
		System.setProperty("webdriver.chrome.driver", "/Users/chriscarela/Documents/jar_Lib/chromedriver");
		driver = new ChromeDriver();

		// Firefox Driver	   
		//System.setProperty("webdriver.gecko.driver", "/Users/chriscarela/Documents/jar_Lib/geckodriver");
		//driver = new FirefoxDriver();
		
		driver.manage().timeouts().implicitlyWait(10,  TimeUnit.SECONDS);
		driver.get(URL);
		driver.manage().window().maximize();
	}
	
//	Note: @AfterClass behavior below will execute before each test case
	@AfterClass
	public void tearDown(){
		if(driver != null){
			driver.manage().deleteAllCookies();
			driver.quit();
		}
	}
	
	
	public static WebDriver getDriver(){
		return driver;
	}	
}
	
	
		

	


