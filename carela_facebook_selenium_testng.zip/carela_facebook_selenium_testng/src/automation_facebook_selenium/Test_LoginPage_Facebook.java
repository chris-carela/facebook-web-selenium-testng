package automation_facebook_selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

/* 
Class Purpose:
	- In this class you'll find 3 test cases
		1) Successful Facebook Account Login
		2) Unsuccessful Facebook Account Login
		3) Successful Facebook Account Creation
	- This class will follow a Page Object Model, elements have been declared as field level variables
	- Test cases will then call variables as needed
	- Overall, optimizing the maintainability of the test cases
		1) Changes to element id's or associated information will only need to be changed in one place (field level)
		2) This format will automatically update all test cases associated with the updated element
	
Misc. Notes:
	- Please replace the placeholder text with valid login credentials, for example, areas labeled 
	with "Replace_This_Text@email.com" with an actual email address
	- Test cases will execute in priority order, starting with 0
*/

public class Test_LoginPage_Facebook extends WebDriverFactory {

	// Note: Elements used throughout test cases 
	private By email = By.id("email");
	private By password = By.id("pass");
	private By login_button = By.xpath("//*[@id='u_0_2']");
	private By recover_account = By.linkText("Recover Your Account");
	private By signup_first_name = By.id("u_0_e");
	private By signup_last_name = By.id("u_0_g");
	private By signup_email = By.id("u_0_j");
	private By signup_email_again = By.id("u_0_m");
	private By signup_password = By.id("u_0_q");
	private By signup_bday_month = By.id("month");
	private By signup_bday_day = By.id("day");
	private By signup_bday_year = By.id("year");
	private By signup_submit = By.id("u_0_y");
	
	// Notes: Elements that were not used but are on page
	private By signup_gender_male = By.xpath("//*[contains(text(),'Male')]");
	private By signup_gender_female = By.id("u_0_5");
	private By signup_gender_custom = By.id("u_0_7");
	private By signup_gender_pronoun = By.xpath("//*[@id='u_0_v']/select");
	private By signup_gender_enter = By.id("u_0_w");

	
	@Test(priority = 0)
	public void Successful_Login() {
		getDriver().findElement(email).sendKeys("Replace_This_Text@email.com");
		getDriver().findElement(password).sendKeys("Replace With Password");
		getDriver().findElement(login_button).click();
	}

	@Test (priority=1)
	public void Failed_Login() { 
		getDriver().findElement(email).sendKeys("DO NOT_Replace_This_Text@email.com");
		getDriver().findElement(password).sendKeys("DO NOT Replace With Password");
		getDriver().findElement(login_button).click();
		
		// Note: Using the driver to validate elements store via function
		List<WebElement> dynamicElement = getDriver().findElements(recover_account);
		// Note: The List should not be equal to 0 when elements are stored
		if(dynamicElement.size() != 0){
			// Note: When it is not equal to 0, the test will pass
			Assert.assertTrue(true);
		}
		else{
			// Note: When it is equal to 0, the test will fail
			Assert.assertTrue(false);
		}
	}
	
	@Test (priority=2)
	public void Create_Account() throws InterruptedException { 
		getDriver().findElement(signup_first_name).sendKeys("Replace with first name");
		getDriver().findElement(signup_last_name).sendKeys("Replace with last name");
		getDriver().findElement(signup_email).sendKeys("Replace_This_Text@email.com");
		getDriver().findElement(signup_email_again).sendKeys("Replace_This_Text@email.com");
		getDriver().findElement(signup_password).sendKeys("Replace with password");
		
		// Note: Implementing Select to choose specific elements from the dropdown menu
		getDriver().findElement(signup_bday_month).click();
		Select month = new Select(getDriver().findElement((signup_bday_month)));
		month.selectByVisibleText("Jul");
		
		getDriver().findElement(signup_bday_day).click();
		Select day = new Select(getDriver().findElement((signup_bday_day)));
		day.selectByVisibleText("26");
		
		getDriver().findElement(signup_bday_year).click();
		Select year = new Select(getDriver().findElement((signup_bday_year)));
		year.selectByVisibleText("1993");
		
		getDriver().findElement(signup_gender_male).click();
		getDriver().findElement(signup_submit).click();
	}
}